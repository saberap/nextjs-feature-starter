import React from "react";

import { Providers } from "@/redux/providers";
import "@/styles/globals.scss";

export const metadata = {
  title: "Next.js",
  description: "",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head></head>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
