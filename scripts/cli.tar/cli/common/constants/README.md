# Welcome to Constants!
You should use this directory to define anything static. Definition of **endpoint APIs**, **regex**, **Farsi equivalent** of statuses, etc. should all be placed in this section.

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`sample-name.constant.ts`*.
 3. your constant props should **have interface**. 
 4. For create new constant you **should** use `npm run create:constant CONSTANT_NAME`. You are **not** allowed to create constant files manually.

# Examples 

Suppose we want to create a **User statuses Constant**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:constant users`.
 2. A file with the name `users.constant.ts` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
interface  UsersType  {  }
export  const  users: UsersType  =  {  }
```

 4. Now customize our users constant:

```ts
interface  UsersType  {
	statuses:  {
		[key:  string]:  string;
	};
}


export  const  users:  UsersType  =  {
	statuses:  {
		active:  'فعال',
		deActive:  'غیر فعال'
	},
};
```
