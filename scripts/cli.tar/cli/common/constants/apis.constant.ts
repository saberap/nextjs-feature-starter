type CallablePath = (...params: string[]) => string
type Path = CallablePath | string

export interface IAPI {
  name: string
  path: any
  APIs?: IAPI[]
}

const apis: IAPI[] = [
  {
    name: 'API',
    path: '/api',
    APIs: [
      {
        name: 'VERSION_1',
        path: '/v1',
        APIs: [],
      },
    ],
  },
]

const convert = (apiItems: IAPI[]): Map<string, IAPI> => {
  const apisMap: Map<string, IAPI> = new Map()

  ;(function makeIterableAPIS(items, prefix = '') {
    const currentPrefix = prefix
    items.forEach((item) => {
      let apiObj: IAPI
      if (item.APIs) {
        const itemPrefix = currentPrefix + item.path
        makeIterableAPIS(item.APIs, itemPrefix as string)
      } else {
        let path: Path
        if (typeof item.path === 'function') {
          path = (...rest: string[]): string =>
            currentPrefix + item.path(...rest)
        } else {
          path = currentPrefix + item.path
        }
        apiObj = {
          ...item,
          path,
        }
        apisMap.set(item.name, apiObj)
      }
    })
  })(apiItems)

  return apisMap
}

export default convert(apis)
