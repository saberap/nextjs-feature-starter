# Welcome to Configs!
This section is for your configs.

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`sample-name.config.ts`*.
 3. your config props should **have interface**. 
 4. For create new config you **should** use `npm run create:config CONFIG_NAME`. You are **not** allowed to create config files manually.

# Examples 

Suppose we want to create a **App Config**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:config app`.
 2. A file with the name `app.config.ts` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
interface  AppConfig  {
	siteNameFa:  string;
	siteNameEn:  string;
	siteDescription:  string;
	siteUrl:  string;
	themeColor:  string;
	mobileWidth:  number;
}

export  const  appConfig:  AppConfig  =  {
	siteNameFa:  'عنوان فارسی',
	siteDescription:'...',
	siteNameEn:  'EnglishName',
	siteUrl:  'https://name.com',
	themeColor:  '#0d5984',
	mobileWidth:  450,
};
```
Now you can customize your app config :)
