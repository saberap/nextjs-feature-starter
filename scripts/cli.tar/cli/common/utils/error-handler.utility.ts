/* eslint-disable import/prefer-default-export */
/* eslint-disable no-unused-vars */
import { isRejectedWithValue } from "@reduxjs/toolkit";
import type { MiddlewareAPI, Middleware } from "@reduxjs/toolkit";

/**
 * Log a warning and show a toast!
 */
export const rtkQueryErrorLogger: Middleware =
  (api: MiddlewareAPI) => (next) => (action) => {
    if (isRejectedWithValue(action)) {
      // console.warn(`We got a rejected action! ${action.error.message}`);
    }
    return next(action);
  };
