# Welcome to Utils!
JavaScript utility functions are useful, reusable snippets that you can reuse across many different projects. Their purpose is to provide a consistent and efficient answer to common tasks and help improve the consistency of your code.

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`sample-name.utility.ts`*.
 3. your utility function should **have interface**. 
 4. For create new utility you **should** use `npm run create:utility UTILITY_NAME`. You are **not** allowed to create utility files manually.

# Examples 

Suppose we want to create a **Currency function**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:utility currency`.
 2. A file with the name `currency.utility.ts` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
interface  CurrencyUtilityParams  {}

type  CurrencyUtilityReturn  =  string;

export  function  currencyUtility(params:  CurrencyUtilityParams):  CurrencyUtilityReturn  {
	return  '';
}
```

 4. Now customize our utility.

```ts
import appConfigs from  '@/common/configs/appConfigs';

interface  CurrencyUtilityParams  {
	price:number
}

type  CurrencyUtilityReturn  =  string;

export  function  currencyUtility({ price }:  CurrencyUtilityParams):  CurrencyUtilityReturn  {
	return  `${price}  ${appConfigs.currency}`;
}
```




