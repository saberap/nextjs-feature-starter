/* eslint-disable no-mixed-operators */
/* eslint-disable import/prefer-default-export */
import { fetchBaseQuery } from "@reduxjs/toolkit/query";
import type {
  BaseQueryFn,
  FetchArgs,
  FetchBaseQueryError,
} from "@reduxjs/toolkit/query";
import { Mutex } from "async-mutex";

//import { revokeToken } from '@/common/slices/auth.slice';

import { AppState } from "@/redux/store";

const mutex = new Mutex();
const customWindow =
  typeof window !== "undefined" && (window as unknown as any);

const baseQuery = fetchBaseQuery({
  baseUrl:
    typeof window === "undefined"
      ? customWindow._env_?.API_BASE_URL
      : process.env.API_BASE_URL,
  prepareHeaders: (headers, { getState, endpoint }) => {
    const { accessToken } = (getState() as AppState).auth;
    if ((accessToken && endpoint !== "refresh") || endpoint !== "revoke") {
      headers.set("Authorization", `Bearer ${accessToken}`);
    }
    return headers;
  },
});

const baseQueryWithInterceptors: BaseQueryFn<
  string | FetchArgs,
  unknown,
  FetchBaseQueryError
> = async (args, api, extraOptions) => {
  // wait until the mutex is available without locking it
  await mutex.waitForUnlock();
  const result = await baseQuery(args, api, extraOptions);

  if (result.error && result.error.status === 401) {
    // checking whether the mutex is locked
    // api.dispatch(revokeToken());
    // if (!mutex.isLocked()) {
    //   const release = await mutex.acquire();
    //   try {
    //     // try to get a new token
    //     const { refreshToken } = (api.getState() as AppState).auth;
    //     const refreshResult: any = await baseQuery(
    //       {
    //         url: apis.get('GET_REFRESH_TOKEN')?.path,
    //         method: 'POST',
    //         body: { refreshToken },
    //       },
    //       { ...api, endpoint: 'refresh' },
    //       extraOptions
    //     );
    //     if (refreshResult && refreshResult.error) {
    //       // revoke token
    //       await baseQuery(
    //         {
    //           url: apis.get('GET_REVOKE_TOKEN')?.path,
    //           method: 'POST',
    //           body: { refreshToken },
    //         },
    //         { ...api, endpoint: 'revoke' },
    //         extraOptions
    //       );
    //       api.dispatch(revokeToken());
    //     }
    //     if (refreshResult.data.data) {
    //       // store the new token
    //       api.dispatch(setLogin(refreshResult.data.data));
    //       // retry the initial query
    //       result = await baseQuery(args, api, extraOptions);
    //     }
    //   } catch (error) {
    //     // console.log(error);
    //   } finally {
    //     // release must be called once the mutex should be released again.
    //     release();
    //   }
    // } else {
    //   // wait until the mutex is available without locking it
    //   await mutex.waitForUnlock();
    //   result = await baseQuery(args, api, extraOptions);
    // }
  }

  return result;
};

export { baseQueryWithInterceptors };
