# Welcome to Components!
This section is for your components.
I believe that if you want your application to be able to develop quickly, you should componentize every small element. Even small things like a **text component**.

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`sample-name.component.ts`*.
 3. your component props should **have interface**. 
 4. For create new api you **should** use `npm run create:component COMPONENT_NAME`. You are **not** allowed to create component files manually.
 5. You **should use [tailwindcss](https://tailwindcss.com/)** for style elements of component.

# Examples

Suppose we want to create a **Button component**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:component button`.
 2. A file with the name `button.component.tsx` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
import React,  {  ReactNode  }  from  'react';

type  Props  =  {
	children:  ReactNode;
};

export  default  function  Button({  children  }:  Props)  {
	return  <div  className='flex items-center justify-center'>{children}</div>;
}
```
Now you can customize your button component :)
