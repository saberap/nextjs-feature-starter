# Welcome to Contexts!
Place React contexts in this section. For more information on what contexts are, [read here](https://react.dev/reference/react/createContext).

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`context.constant.ts`*.
 3. your context should **have interface**. 
 4. For create new constant you **should** use `npm run create:context CONTEXT_NAME`. You are **not** allowed to create context files manually.

# Examples 

Suppose we want to create a **Layout Context**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:context layout`.
 2. A file with the name `layout.context.ts` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
import  {  createContext  }  from  'react';

interface  LayoutContext  { }

const  layoutContext  =  createContext<LayoutContext  |  null>(null);

export  default  layoutContext;
```

 4. Now customize our layout context:

```ts
import  {  createContext  }  from  'react';

interface  LayoutContext  {
	mode:  'dark'  |  'light';
}

const  layoutContext  =  createContext<LayoutContext  |  null>(null);

export  default  layoutContext;
```

