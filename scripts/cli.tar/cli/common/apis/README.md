# Welcome to Apis!
This section is for placing API services that are written with **[ReduxToolkitQuery(RTK)](https://redux-toolkit.js.org/rtk-query/overview)**.

## Rules

 1. Naming your files **should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).
 2. The files **should** have extensions *`sample-name.api.ts`*.
 3. Create only **one** file for several APIs related to the same service. For example, the user service `CRUD APIs(Create, Read, Update and Delete)` are all placed in one file named `users.api.ts` , and you are **not** allowed to create multiple files for each API like `create-user.api.ts, delete-user.api.ts and ....`
 4. At the time of writing the API should be written based on **typescript**. An interface **must be written** for payload and response of **each api**.
 5. For create new api you **should** use `npm run create:api API_NAME`. You are **not** allowed to create api files manually.

# Examples

Suppose we want to create a **user** service, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:api users`.
 2. A file with the name `users.api.ts` will be created in this directory.
 3. Open it and you will probably see something like this:
```ts
// Need to use the React-specific entry point to allow generating React hooks
import  {  createApi  }  from  '@reduxjs/toolkit/query/react';

import  {  baseQueryWithInterceptors  }  from  '@/common/utils/base-query.utility';
import  {  UsersItem,  UsersQueryParams  }  from  '@/common/types/users.types';
import  {  ItemsResponse  }  from  '@/common/types/response.types';
import apis from  '@/common/constants/apis.constant';

export  const usersApi =  createApi({
	reducerPath:  'usersApi',
	baseQuery: baseQueryWithInterceptors,
	endpoints:  (builder)  => ({
	getAllUserss: builder.query<ItemsResponse<UsersItem>,  UsersQueryParams>({
	query:  (params)  => ({
					url: apis.get('YOUR_API_NAME')?.path,
					params,
				}),
			}),
		}),
});

// For use in functional components
export  const  {
useGetAllUserssQuery,
util:  { getRunningQueriesThunk },
}  = usersApi;
```

 - Be sure to use `apis.get('YOUR_API_NAME')?.path` to specify the API path.
