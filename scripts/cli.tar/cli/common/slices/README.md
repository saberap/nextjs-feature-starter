# Welcome to Slices!
A function that accepts an initial state, an object of reducer functions, and a "slice name", and automatically generates action creators and action types that correspond to the reducers and state. read more information [here](https://redux-toolkit.js.org/api/createslice).

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`sample-name.slice.ts`*.
 3. Your slice should **have interface**. 
 4. For create new slice you **should** use `npm run create:slice SLICE_NAME`. You are **not** allowed to create slice files manually.

# Examples 

Suppose we want to create a **Counter Slice**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:slice counter`.
 2. A file with the name `counter.slice.ts` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
import  {  createSlice  }  from  '@reduxjs/toolkit'
import  type  {  PayloadAction  }  from  '@reduxjs/toolkit'

interface  InitialState  {
	name:  string;
}

const  initialState:  InitialState  =  {  name:  'Saber'  };

const  counterSlice  =  createSlice({
	name:  'counter',
	initialState,
	reducers:  {
		sample(state,  action:  PayloadAction<string>)  {
			state.name  =  action.payload
		},
	},
})

export  const  {  sample  }  =  counterSlice.actions;

export  default  counterSlice.reducer;
```

 4. Now customize our slice.

```ts
import  {  createSlice  }  from  '@reduxjs/toolkit'
import  type  {  PayloadAction  }  from  '@reduxjs/toolkit'

interface  InitialState  {
	value:  number
}

const  initialState:InitialState  =  {  value:  0  }
const  counterSlice  =  createSlice({
	name:  'counter',
	initialState,
	reducers:  {
	increment(state)  {
		state.value++
	},
	decrement(state)  {
		state.value--
	},
	incrementByAmount(state,  action:  PayloadAction<number>)  {
		state.value  +=  action.payload
	},
	},
})

export  const  {  increment,  decrement,  incrementByAmount  }  =  counterSlice.actions

export  default  counterSlice.reducer
```




