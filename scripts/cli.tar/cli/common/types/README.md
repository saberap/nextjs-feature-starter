# Welcome to Types!
Put all the types that you are sure can be used in several places in this section. For example, the `ResponseItem` type is used in all APIs and it is not logical to define it in all files. Therefore, it is placed in this section.

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`sample-name.type.ts`*.
 3. For create new constant you **should** use `npm run create:type TYPE_NAME`. You are **not** allowed to create type files manually.

# Examples 

Suppose we want to create a **APIs Response**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:type response`.
 2. A file with the name `response.type.ts` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
export  interface  ResponseType  {}
```

 4. Now customize our type.

```ts
export  interface  ResponseItemsType<T>  {

	data:  {
		items:  T;
	};

}

export  interface  ResponseItemType<T>  {
	data:  T;
}
```




