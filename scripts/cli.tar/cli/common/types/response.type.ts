export interface ResponseItemsType<T> {
  data: {
    items: T
  }
}

export interface ResponseItemType<T> {
  data: T
}
