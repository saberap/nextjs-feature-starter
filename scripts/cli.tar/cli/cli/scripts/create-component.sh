#!/bin/sh
INSERTED_NAME=$1;

PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;
#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'

DIR="./src/common/components/$INSERTED_NAME"
if [ -d "$DIR" ]; then
  # Take action if $DIR exists. #
  echo -e "${RED}Component ${CYAN}$PASCAL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;

else

mkdir ./src/common/components/$INSERTED_NAME;

#Create Component
echo "import React, { type ReactNode, type ReactElement } from 'react';

interface Props  {
  children: ReactNode;
};

export default function $PASCAL_CASE_NAME({ children }: Props): ReactElement {
  return <div className='flex items-center justify-center'>{children}</div>;
}" >> ./src/common/components/$1/$1.component.tsx;

#Export Module
echo "export { default } from './$INSERTED_NAME.component';" >> ./src/common/components/$INSERTED_NAME/index.ts;


echo -e "${CYAN}$PASCAL_CASE_NAME ${GREEN}Component generated successfully."

fi