#!/bin/sh
INSERTED_NAME=$1;

PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;

CAMEL_CASE_NAME=`echo $PASCAL_CASE_NAME | sed -r 's/^([A-Z])/\l\1/g'`;

#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'

FILE="./src/common/constants/$INSERTED_NAME.constant.ts"
if [ -f "$FILE" ]; then
  # Take action if $FILE exists. #
  echo -e "${RED}Constant ${CYAN}$CAMEL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;

else

#Create Constant
echo "interface  ${PASCAL_CASE_NAME}Type  {  };
export  const  ${CAMEL_CASE_NAME}Constant: ${PASCAL_CASE_NAME}Type  =  {  };" >> ./src/common/constants/$1.constant.ts;



echo -e "${CYAN}$PASCAL_CASE_NAME ${GREEN}Constant generated successfully."

fi