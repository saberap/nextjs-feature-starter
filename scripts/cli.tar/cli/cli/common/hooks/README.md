# Welcome to Hooks!
If you want to create your own custom hook, you should place it here. If you don't know how to create a custom hook, [read here](https://react.dev/learn/reusing-logic-with-custom-hooks).

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files ****should** have extensions** *`use-sample-name.hook.ts`*.
 3. your hook function return should **have interface**. 
 4. For create new constant you **should** use `npm run create:hook HOOK_NAME`. You are **not** allowed to create hook files manually.

# Examples 

Suppose we want to create a **Online Status**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:hook online-status`.
 2. A file with the name `use-online-status.hook.ts` will be created in this directory.
 3. Open it and you will probably see something like this:

```ts
import  {  useState,  useEffect  }  from  'react';

export  function  useOnlineStatus()  {
	const  [sample,  setSample]  =  useState<boolean>(false);

	useEffect(()  =>  {
		//do some thing ...
	}, []);
	
	return  sample;
}
```

 4. Now customize our hook.

```ts
import  {  useState,  useEffect  }  from  'react';
export  function  useOnlineStatus()  {
	const [isOnline, setIsOnline] = useState(true);  
	useEffect(() => {  
		function handleOnline() {  
		setIsOnline(true);  
	}  

	function handleOffline() {  
		setIsOnline(false);  
	}  
	window.addEventListener('online', handleOnline);  
	window.addEventListener('offline', handleOffline);  
	return () => {  
		window.removeEventListener('online', handleOnline);  
		window.removeEventListener('offline', handleOffline);  
	};  
}, []);  

return isOnline;

}
```