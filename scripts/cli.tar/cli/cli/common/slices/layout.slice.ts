import { AppState } from '@/redux/store'
import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'

interface InitialState {
  theme: 'dark' | 'light'
}

const initialState: InitialState = { theme: 'dark' }

const layoutSlice = createSlice({
  name: 'layout',
  initialState,
  reducers: {
    setTheme(state, action: PayloadAction<InitialState['theme']>) {
      state.theme = action.payload
    },
  },
})

export const { setTheme } = layoutSlice.actions

export const selectTheme = (state: AppState) => state.layout.theme

export default layoutSlice.reducer
