# Welcome to Features!
Another way to organize things is to introduce **features**.  
Features help group together code that is related to each other. They're not a replacement for what's common.
Imagine we added a new `src/features/` folder where we group all the files related to a feature (here for example `Login`), instead of splitting the "Login" code all over the place, now in one folder The unit is concentrated.

Creating `Login` feature involves organizing its components and types in close proximity. In this context, "components" refer to placing feature-specific parts within the designated component folder associated with that feature.

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files in each directory of a feature must follow the extension rules.  For example, the files in the components directory should be in the form `sample-name.component.tsx` and the files in the types directory should be in the form `sample-name.type.ts`.
 3. Components should **have interface**. 
 4. For create new feature you **should** use `npm run create:feature MODULE_NAME`. You are **not** allowed to create feature files manually.

# Examples 

Suppose we want to create a **Login Module**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:feature login`.
 2. A directory with the name `login` will be created in `/src/features` directory.

	```lua
	src
	└── features
		    └── login
		        ├── components
		        │   └── sample.component.tsx
		        ├── types
		        │   └── sample.type.ts
		        ├── login.feature.tsx
		        └── index.ts
	 ```

 3. A directory with the name `login`  will be created in `/src/app` directory.
	```lua
		src
		└── app
			 └── login
			        └── page.tsx
	```