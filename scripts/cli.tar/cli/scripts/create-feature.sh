#!/bin/sh
INSERTED_NAME=$1;
FEATURE='Feature';
METADATA='MetaData';
PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;
MODULE_NAME=${PASCAL_CASE_NAME}${FEATURE}
METADATA_NAME=${PASCAL_CASE_NAME}${METADATA}
#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'


DIR="./src/features/$INSERTED_NAME"
if [ -d "$DIR" ]; then
  # Take action if $DIR exists. #
  echo -e "${RED}Feature ${CYAN}$PASCAL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;
else

mkdir ./src/features/$1;
mkdir ./src/app/$1;
mkdir ./src/features/$1/components;

#Create Feature
echo "import React, {type ReactElement} from 'react';
import { Metadata } from 'next';

import Sample from '@/features/$INSERTED_NAME/components/sample.component';

export const metadata: Metadata = {
  title: '$PASCAL_CASE_NAME',
  description: '...'
};

export default function $PASCAL_CASE_NAME(): ReactElement {
  return (
    <div>
      <div className='flex items-center justify-center'>
        <div className='flex items-center justify-center'>
          <Sample title='This is a sample component :)' />
        </div>
      </div>
    </div>
  );
}
" >> ./src/features/$INSERTED_NAME/$INSERTED_NAME.feature.tsx;

#Export Feature
echo "export { default } from './$INSERTED_NAME.feature';" >> ./src/features/$INSERTED_NAME/index.ts;
echo "export { metadata as $METADATA_NAME }  from './$INSERTED_NAME.feature';" >> ./src/features/$INSERTED_NAME/index.ts;

#Create sample component
echo "import React, {type ReactElement } from 'react';

interface Props = {
  title: string;
};

export default function Sample({ title }: Props): ReactElement {
  return (
    <div className='flex items-center justify-center'>
      <div className='flex items-center justify-center'>{title}</div>
    </div>
  );
}" >> ./src/features/$INSERTED_NAME/components/sample.component.tsx;


#Create App Page 
echo "import React, { type ReactElement } from 'react';
import $MODULE_NAME, { $METADATA_NAME } from '@/features/$1';

export const metadata = $METADATA_NAME


export default function  $PASCAL_CASE_NAME(): ReactElement {
  return <$MODULE_NAME />;
}
" >> ./src/app/$1/page.tsx

echo -e "${CYAN}$PASCAL_CASE_NAME ${GREEN}Feature generated successfully."

fi