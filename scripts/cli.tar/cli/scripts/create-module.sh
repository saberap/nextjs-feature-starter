#!/bin/sh
INSERTED_NAME=$1;
MODULE='Module';
METADATA='MetaData';
PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;
MODULE_NAME=${PASCAL_CASE_NAME}${MODULE}
METADATA_NAME=${PASCAL_CASE_NAME}${METADATA}
#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'


DIR="./src/modules/$INSERTED_NAME"
if [ -d "$DIR" ]; then
  # Take action if $DIR exists. #
  echo -e "${RED}Module ${CYAN}$PASCAL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;
else

mkdir ./src/modules/$1;
mkdir ./src/app/$1;
mkdir ./src/modules/$1/components;
mkdir ./src/modules/$1/types;

#Create Module
echo "import React from 'react';
import { Metadata } from 'next';

import Sample from '@/modules/$INSERTED_NAME/components/sample.component';

export const metadata: Metadata = {
  title: '$PASCAL_CASE_NAME',
  description: '...'
};

export default function $PASCAL_CASE_NAME() {
  return (
    <div>
      <div className='flex items-center justify-center'>
        <div className='flex items-center justify-center'>
          <Sample title='This is a sample component :)' />
        </div>
      </div>
    </div>
  );
}
" >> ./src/modules/$INSERTED_NAME/$INSERTED_NAME.module.tsx;

#Export Module
echo "export { default } from './$INSERTED_NAME.module';" >> ./src/modules/$INSERTED_NAME/index.ts;
echo "export { metadata as $METADATA_NAME }  from './$INSERTED_NAME.module';" >> ./src/modules/$INSERTED_NAME/index.ts;

#Create sample component
echo "import React from 'react';

type Props = {
  title: string;
};

export default function Sample({ title }: Props) {
  return (
    <div className='flex items-center justify-center'>
      <div className='flex items-center justify-center'>{title}</div>
    </div>
  );
}" >> ./src/modules/$INSERTED_NAME/components/sample.component.tsx;

#Create sample type 
echo "export interface Sample {
  name: string;
}" >> ./src/modules/$INSERTED_NAME/types/sample.type.ts;

#Create App Page 
echo "import React from 'react';
import $MODULE_NAME, { $METADATA_NAME } from '@/modules/$1';

export const metadata = $METADATA_NAME


export default function  $PASCAL_CASE_NAME() {
  return <$MODULE_NAME />;
}
" >> ./src/app/$1/page.tsx

echo -e "${CYAN}$PASCAL_CASE_NAME ${GREEN}Module generated successfully."

fi