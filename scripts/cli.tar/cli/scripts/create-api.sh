#!/bin/sh
INSERTED_NAME=$1;

PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;

CAMEL_CASE_NAME=`echo $PASCAL_CASE_NAME | sed -r 's/^([A-Z])/\l\1/g'`;
#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'


FILE="./src/common/apis/$INSERTED_NAME.api.ts"
if [ -f "$FILE" ]; then
  # Take action if $DIR exists. #
  echo -e "${RED}Api ${CYAN}$CAMEL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;

else

#Create types 
echo "export interface ${PASCAL_CASE_NAME}Item {
  key: string;
  value: string;
}
export interface ${PASCAL_CASE_NAME}QueryParams {
  type: 'foo' | 'bar';
}" >> ./src/common/types/$INSERTED_NAME.types.ts;
#Create Api
echo "// Need to use the React-specific entry point to allow generating React hooks
import { createApi } from '@reduxjs/toolkit/query/react';

import { baseQueryWithInterceptors } from '@/common/utils/base-query.utility';
import { ${PASCAL_CASE_NAME}Item, ${PASCAL_CASE_NAME}QueryParams } from '@/common/types/${INSERTED_NAME}.types';
import { ItemsResponse } from '@/common/types/response.types';
import apis from '@/common/constants/apis.constant';

export const ${CAMEL_CASE_NAME}Api = createApi({
  reducerPath: '${CAMEL_CASE_NAME}Api',
  baseQuery: baseQueryWithInterceptors,

  endpoints: (builder) => ({
    getAll${PASCAL_CASE_NAME}s: builder.query<ItemsResponse<${PASCAL_CASE_NAME}Item>, ${PASCAL_CASE_NAME}QueryParams>({
      query: (params) => ({
        url: apis.get('YOUR_API_NAME')?.path,
        params,
      }),
    }),
  }),
});

// For use in functional components
export const {
  useGetAll${PASCAL_CASE_NAME}sQuery,
  util: { getRunningQueriesThunk },
} = ${CAMEL_CASE_NAME}Api;" >> ./src/common/apis/$1.api.ts;

#Edit middlewares file
sed "/\export/i import { ${CAMEL_CASE_NAME}Api } from '@/common/apis/${INSERTED_NAME}.api';\n" ./src/redux/middlewares.ts > ./src/redux/new_middlewares.ts;
mv ./src/redux/new_middlewares.ts ./src/redux/middlewares.ts;
sed "s/\]/, ${CAMEL_CASE_NAME}Api.middleware&/" ./src/redux/middlewares.ts > ./src/redux/new_middlewares.ts;
mv ./src/redux/new_middlewares.ts ./src/redux/middlewares.ts

#edit reducers file
sed "/\export/i import { ${CAMEL_CASE_NAME}Api } from '@/common/apis/${INSERTED_NAME}.api';\n" ./src/redux/reducers.ts > ./src/redux/new_reducers.ts;
mv ./src/redux/new_reducers.ts ./src/redux/reducers.ts;
sed "s/\};/  [${CAMEL_CASE_NAME}Api.reducerPath]: ${CAMEL_CASE_NAME}Api.reducer,\n&/" ./src/redux/reducers.ts > ./src/redux/new_reducers.ts;
mv ./src/redux/new_reducers.ts ./src/redux/reducers.ts


echo -e "${CYAN}$CAMEL_CASE_NAME ${GREEN}Api generated successfully."

fi