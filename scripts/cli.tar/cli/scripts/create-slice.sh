#!/bin/sh
INSERTED_NAME=$1;

PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;

CAMEL_CASE_NAME=`echo $PASCAL_CASE_NAME | sed -r 's/^([A-Z])/\l\1/g'`;

#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'

FILE="./src/common/slices/$1.slice.ts"
if [ -f "$FILE" ]; then
  # Take action if $FILE exists. #
  echo -e "${RED}Slice ${CYAN}$CAMEL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;

else

#Create Utility
echo "import { createSlice } from '@reduxjs/toolkit'
import type { PayloadAction } from '@reduxjs/toolkit'

interface InitialState { 
    name: string;
}

const initialState: InitialState = { name: 'Saber' };

const ${CAMEL_CASE_NAME}Slice = createSlice({
  name: '${CAMEL_CASE_NAME}',
  initialState,
  reducers: {
    sample(state, action: PayloadAction<string>) {
      state.name = action.payload
    },
  },
})

export const { sample } = ${CAMEL_CASE_NAME}Slice.actions;

export default ${CAMEL_CASE_NAME}Slice.reducer;" >> ./src/common/slices/$1.slice.ts;



echo -e "${CYAN}$PASCAL_CASE_NAME ${GREEN}Slice generated successfully."

fi