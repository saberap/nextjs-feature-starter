#!/bin/sh
INSERTED_NAME=$1;

PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;

CAMEL_CASE_NAME=`echo $PASCAL_CASE_NAME | sed -r 's/^([A-Z])/\l\1/g'`;

#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'

FILE="./src/common/hooks/use-$1.hook.ts"
if [ -f "$FILE" ]; then
  # Take action if $FILE exists. #
  echo -e "${RED}Hook ${CYAN}$CAMEL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;

else

#Create Constant
echo "import { useState, useEffect } from 'react';

export function use${PASCAL_CASE_NAME}() {
  const [sample, setSample] = useState<boolean>(false);

  useEffect(() => {
    //do some thing ...
  }, []);

  return sample;
}" >> ./src/common/hooks/use-$1.hook.ts;



echo -e "${CYAN}$PASCAL_CASE_NAME ${GREEN}Hook generated successfully."

fi