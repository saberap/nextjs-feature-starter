#!/bin/sh
INSERTED_NAME=$1;

PASCAL_CASE_NAME=`echo $INSERTED_NAME | sed -r 's/(^|-)([a-z])/\U\2/g'`;

CAMEL_CASE_NAME=`echo $PASCAL_CASE_NAME | sed -r 's/^([A-Z])/\l\1/g'`;

#Colors
RED='\033[1;31m' 
GREEN='\033[1;32m'
CYAN='\033[1;96m'

FILE="./src/common/contexts/$INSERTED_NAME.context.ts"
if [ -f "$FILE" ]; then
  # Take action if $FILE exists. #
  echo -e "${RED}Context ${CYAN}$CAMEL_CASE_NAME ${RED}already exists. Please try another name."
  exit 1;

else

#Create Constant
echo "import  {  createContext  }  from  'react';

interface  ${PASCAL_CASE_NAME}ContextType  { }

export const  ${PASCAL_CASE_NAME}Context  =  createContext<${PASCAL_CASE_NAME}ContextType  |  null>(null);" >> ./src/common/contexts/$1.context.ts;



echo -e "${CYAN}$PASCAL_CASE_NAME ${GREEN}Context generated successfully."

fi