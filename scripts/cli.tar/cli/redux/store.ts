import { configureStore } from "@reduxjs/toolkit";
// import storage from "redux-persist/lib/storage";
import {
  // persistReducer,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from "redux-persist";
import { combineReducers } from "redux";
import { rtkQueryErrorLogger } from "@/common/utils/error-handler.utility";

import middlewares from "./middlewares";
import reducers from "./reducers";

// Slices

// const persistLayout = {
//   key: "layout",
//   storage,
// };

const appReducers = combineReducers({
  //  layout: persistReducer(persistLayout, layout),
  ...reducers,
});

export const store = configureStore({
  reducer: appReducers,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    })
      .concat(rtkQueryErrorLogger)
      .concat(middlewares),
  devTools: true,
});

// Infer the `RootState` and `AppDispatch` types from the store itself
export type AppState = ReturnType<typeof store.getState>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch;
