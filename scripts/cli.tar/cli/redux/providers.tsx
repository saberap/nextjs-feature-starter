'use client';

import React from 'react';
import { PersistGate } from 'redux-persist/integration/react';
import { Provider } from 'react-redux';
import { persistStore } from 'redux-persist';

import { store } from './store';

const persistore = persistStore(store);

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <Provider store={store}>
      <PersistGate persistor={persistore} loading={null}>
        <>{children}</>
      </PersistGate>
    </Provider>
  );
}
