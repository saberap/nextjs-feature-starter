# Welcome to Modules!
Another way to organize things is to introduce **modules**.  
Modules help group together code that is related to each other. They're not a replacement for what's common.
Imagine we added a new `src/modules/` folder where we group all the files related to a feature (here for example `Login`), instead of splitting the "Login" code all over the place, now in one folder The unit is concentrated.

Creating `Login` module involves organizing its components and types in close proximity. In this context, "components" refer to placing module-specific parts within the designated component folder associated with that module.

## Rules

 1. Naming your files ****should** follow the [kabab-case rule](https://developer.mozilla.org/en-US/docs/Glossary/Kebab_case).**
 2. The files in each directory of a module must follow the extension rules.  For example, the files in the components directory should be in the form `sample-name.component.tsx` and the files in the types directory should be in the form `sample-name.type.ts`.
 3. Components should **have interface**. 
 4. For create new module you **should** use `npm run create:module MODULE_NAME`. You are **not** allowed to create module files manually.

# Examples 

Suppose we want to create a **Login Module**, the steps are as follows:

 1. First run this command in [GitBash](https://gitforwindows.org/) terminal, `npm run create:module login`.
 2. A directory with the name `login` will be created in `/src/modules` directory.

	```lua
	src
	└── modules
		    └── login
		        ├── components
		        │   └── sample.component.tsx
		        ├── types
		        │   └── sample.type.ts
		        ├── login.module.tsx
		        └── index.ts
	 ```

 3. A directory with the name `login`  will be created in `/src/app` directory.
	```lua
		src
		└── app
			 └── login
			        └── page.tsx
	```